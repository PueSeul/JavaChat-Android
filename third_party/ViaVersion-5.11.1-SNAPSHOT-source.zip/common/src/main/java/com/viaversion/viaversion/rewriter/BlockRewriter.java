/*
 * This file is part of ViaVersion - https://github.com/ViaVersion/ViaVersion
 * Copyright (C) 2016-2026 ViaVersion and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.viaversion.viaversion.rewriter;

import com.google.common.base.Preconditions;
import com.viaversion.nbt.tag.CompoundTag;
import com.viaversion.viaversion.api.connection.UserConnection;
import com.viaversion.viaversion.api.data.FullMappings;
import com.viaversion.viaversion.api.data.MappingData;
import com.viaversion.viaversion.api.data.Mappings;
import com.viaversion.viaversion.api.data.entity.EntityTracker;
import com.viaversion.viaversion.api.minecraft.BlockChangeRecord;
import com.viaversion.viaversion.api.minecraft.BlockPosition;
import com.viaversion.viaversion.api.minecraft.blockentity.BlockEntity;
import com.viaversion.viaversion.api.minecraft.blockentity.BlockEntityImpl;
import com.viaversion.viaversion.api.minecraft.chunks.Chunk;
import com.viaversion.viaversion.api.minecraft.chunks.ChunkSection;
import com.viaversion.viaversion.api.minecraft.chunks.DataPalette;
import com.viaversion.viaversion.api.minecraft.chunks.PaletteType;
import com.viaversion.viaversion.api.protocol.Protocol;
import com.viaversion.viaversion.api.protocol.packet.ClientboundPacketType;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.type.Type;
import com.viaversion.viaversion.api.type.Types;
import com.viaversion.viaversion.util.MathUtil;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import java.util.List;
import java.util.function.BiConsumer;
import org.checkerframework.checker.nullness.qual.Nullable;

public class BlockRewriter<C extends ClientboundPacketType> {
    protected final Protocol<C, ?, ?, ?> protocol;
    private final Type<BlockPosition> positionType;
    private final Type<CompoundTag> compoundTagType;
    private final ChunkTypeSupplier chunkTypeSupplier;
    private final ChunkTypeSupplier mappedChunkTypeSupplier;

    public BlockRewriter(
        final Protocol<C, ?, ?, ?> protocol,
        final Type<BlockPosition> positionType, final Type<CompoundTag> compoundTagType,
        final ChunkTypeSupplier chunkTypeSupplier, @Nullable final ChunkTypeSupplier mappedChunkTypeSupplier
    ) {
        this.protocol = protocol;
        this.positionType = positionType;
        this.compoundTagType = compoundTagType;
        this.chunkTypeSupplier = chunkTypeSupplier;
        this.mappedChunkTypeSupplier = mappedChunkTypeSupplier;
    }

    public static <C extends ClientboundPacketType> BlockRewriter<C> legacy(final Protocol<C, ?, ?, ?> protocol) {
        return new BlockRewriter<>(protocol, Types.BLOCK_POSITION1_8, Types.NAMED_COMPOUND_TAG, null, null);
    }

    public static <C extends ClientboundPacketType> BlockRewriter<C> for1_14(final Protocol<C, ?, ?, ?> protocol) {
        return new BlockRewriter<>(protocol, Types.BLOCK_POSITION1_14, Types.NAMED_COMPOUND_TAG, null, null);
    }

    public static <C extends ClientboundPacketType> BlockRewriter<C> for1_18(final Protocol<C, ?, ?, ?> protocol, final ChunkTypeSupplier chunkTypeSupplier) {
        return for1_18(protocol, chunkTypeSupplier, null);
    }

    public static <C extends ClientboundPacketType> BlockRewriter<C> for1_18(final Protocol<C, ?, ?, ?> protocol, final ChunkTypeSupplier chunkTypeSupplier, final ChunkTypeSupplier mappedChunkTypeSupplier) {
        return new BlockRewriter<>(protocol, Types.BLOCK_POSITION1_14, Types.NAMED_COMPOUND_TAG, chunkTypeSupplier, mappedChunkTypeSupplier);
    }

    public static <C extends ClientboundPacketType> BlockRewriter<C> for1_20_2(final Protocol<C, ?, ?, ?> protocol, final ChunkTypeSupplier chunkTypeSupplier) {
        return for1_20_2(protocol, chunkTypeSupplier, null);
    }

    public static <C extends ClientboundPacketType> BlockRewriter<C> for1_20_2(final Protocol<C, ?, ?, ?> protocol, final ChunkTypeSupplier chunkTypeSupplier, final ChunkTypeSupplier mappedChunkTypeSupplier) {
        return new BlockRewriter<>(protocol, Types.BLOCK_POSITION1_14, Types.TRUSTED_COMPOUND_TAG, chunkTypeSupplier, mappedChunkTypeSupplier);
    }
    // See the block package for more recent versions

    public void registerBlockEvent(C packetType) {
        if (Mappings.isIntIdIdentity(protocol.getMappingData().getBlockMappings())) {
            return;
        }
        protocol.registerClientbound(packetType, wrapper -> {
            wrapper.passthrough(positionType); // Location
            wrapper.passthrough(Types.UNSIGNED_BYTE); // Action id
            wrapper.passthrough(Types.UNSIGNED_BYTE); // Action param
            final int blockId = wrapper.passthrough(Types.VAR_INT);
            final int mappedId = protocol.getMappingData().getNewBlockId(blockId);
            if (mappedId == -1) {
                wrapper.cancel();
                return;
            }

            if (blockId != mappedId) {
                wrapper.set(Types.VAR_INT, 0, mappedId);
            }
        });
    }

    public void registerBlockUpdate(C packetType) {
        if (Mappings.isIntIdIdentity(protocol.getMappingData().getBlockStateMappings())) {
            return;
        }
        protocol.registerClientbound(packetType, wrapper -> {
            wrapper.passthrough(positionType);

            final int blockId = wrapper.read(Types.VAR_INT);
            wrapper.write(Types.VAR_INT, protocol.getMappingData().getNewBlockStateId(blockId));
        });
    }

    public void registerChunkBlocksUpdate(C packetType) {
        if (Mappings.isIntIdIdentity(protocol.getMappingData().getBlockStateMappings())) {
            return;
        }
        protocol.registerClientbound(packetType, wrapper -> {
            wrapper.passthrough(Types.INT); // Chunk X
            wrapper.passthrough(Types.INT); // Chunk Z
            for (BlockChangeRecord record : wrapper.passthrough(Types.BLOCK_CHANGE_ARRAY)) {
                record.setBlockId(protocol.getMappingData().getNewBlockStateId(record.getBlockId()));
            }
        });
    }

    public void registerSectionBlocksUpdate(C packetType) {
        if (Mappings.isIntIdIdentity(protocol.getMappingData().getBlockStateMappings())) {
            return;
        }
        protocol.registerClientbound(packetType, wrapper -> {
            wrapper.passthrough(Types.LONG); // Chunk position
            wrapper.passthrough(Types.BOOLEAN); // Suppress light updates
            for (BlockChangeRecord record : wrapper.passthrough(Types.VAR_LONG_BLOCK_CHANGE_ARRAY)) {
                record.setBlockId(protocol.getMappingData().getNewBlockStateId(record.getBlockId()));
            }
        });
    }

    public void registerSectionBlocksUpdate1_20(C packetType) {
        if (Mappings.isIntIdIdentity(protocol.getMappingData().getBlockStateMappings())) {
            return;
        }
        protocol.registerClientbound(packetType, wrapper -> {
            wrapper.passthrough(Types.LONG); // Chunk position
            for (BlockChangeRecord record : wrapper.passthrough(Types.VAR_LONG_BLOCK_CHANGE_ARRAY)) {
                record.setBlockId(protocol.getMappingData().getNewBlockStateId(record.getBlockId()));
            }
        });
    }

    public void registerBlockBreakAck(C packetType) {
        // Same exact handler
        registerBlockUpdate(packetType);
    }

    public void registerLevelEvent1_13(C packetType) {
        registerLevelEvent(packetType, 1010, 2001);
    }

    public void registerLevelEvent1_21(C packetType) {
        registerLevelEvent(packetType, -1, 2001);
    }

    private void registerLevelEvent(C packetType, int playRecordId, int blockBreakId) {
        final MappingData mappingData = protocol.getMappingData();
        if (mappingData == null
            || Mappings.isIntIdIdentity(mappingData.getItemMappings()) && Mappings.isIntIdIdentity(mappingData.getBlockStateMappings())) {
            return;
        }
        protocol.registerClientbound(packetType, wrapper -> {
            final int id = wrapper.passthrough(Types.INT);
            wrapper.passthrough(positionType);

            final int data = wrapper.read(Types.INT);
            if (playRecordId != -1 && id == playRecordId && mappingData.getItemMappings() != null) {
                wrapper.write(Types.INT, mappingData.getNewItemId(data));
            } else if (id == blockBreakId && mappingData.getBlockStateMappings() != null) {
                wrapper.write(Types.INT, mappingData.getNewBlockStateId(data));
            } else {
                wrapper.write(Types.INT, data);
            }
        });
    }

    public void registerLevelChunk(C packetType, Type<Chunk> chunkType, Type<Chunk> newChunkType) {
        registerLevelChunk(packetType, chunkType, newChunkType, null);
    }

    public void registerLevelChunk(C packetType, Type<Chunk> chunkType, Type<Chunk> newChunkType, @Nullable BiConsumer<UserConnection, Chunk> chunkRewriter) {
        protocol.registerClientbound(packetType, wrapper -> {
            Chunk chunk = wrapper.read(chunkType);
            wrapper.write(newChunkType, chunk);

            handleChunk(chunk);
            if (chunkRewriter != null) {
                chunkRewriter.accept(wrapper.user(), chunk);
            }
        });
    }

    public void handleChunk(Chunk chunk) {
        for (int s = 0; s < chunk.getSections().length; s++) {
            ChunkSection section = chunk.getSections()[s];
            if (section == null) {
                continue;
            }

            DataPalette palette = section.palette(PaletteType.BLOCKS);
            palette.replaceIds(protocol.getMappingData()::getNewBlockStateId);
        }
    }

    public void registerLevelChunk1_18(C packetType) {
        protocol.registerClientbound(packetType, wrapper -> {
            final Chunk chunk = handleChunk1_18(wrapper);
            handleBlockEntities(chunk, wrapper.user());
        });
    }

    /**
     * Updates block entity ids, removes block entities mapped to -1, and calls {@link #handleBlockEntity(UserConnection, BlockEntity)} for block entities with data.
     *
     * @param chunk      the chunk
     * @param connection the user connection
     */
    public void handleBlockEntities(Chunk chunk, UserConnection connection) {
        final FullMappings blockEntityMappings = protocol.getMappingData().getBlockEntityMappings();
        final List<BlockEntity> blockEntities = chunk.blockEntities();
        final IntList toRemove = new IntArrayList(0);
        for (int i = 0; i < blockEntities.size(); i++) {
            BlockEntity blockEntity = blockEntities.get(i);
            if (blockEntityMappings != null) {
                final int id = blockEntity.typeId();
                final int mappedId = blockEntityMappings.getNewId(id);
                if (mappedId == -1) {
                    toRemove.add(i);
                    continue;
                }

                if (id != mappedId) {
                    blockEntity = blockEntity.withTypeId(mappedId);
                    blockEntities.set(i, blockEntity);
                }
            }

            if (blockEntity.tag() != null) {
                handleBlockEntity(connection, blockEntity);
            }
        }

        if (!toRemove.isEmpty()) {
            for (int i = toRemove.size() - 1; i >= 0; i--) {
                blockEntities.remove(toRemove.getInt(i));
            }
        }
    }

    public Chunk handleChunk1_18(PacketWrapper wrapper) {
        final EntityTracker tracker = protocol.getEntityRewriter().tracker(wrapper.user());
        Preconditions.checkArgument(tracker.biomesSent() != -1, "Biome count not set");
        Preconditions.checkArgument(tracker.currentWorldSectionHeight() != -1, "Section height not set");
        final Type<Chunk> chunkType = createChunkType(chunkTypeSupplier, tracker, false);
        final Type<Chunk> mappedChunkType = mappedChunkTypeSupplier != null
            ? createChunkType(mappedChunkTypeSupplier, tracker, true)
            : chunkType;
        final Chunk chunk = wrapper.passthroughAndMap(chunkType, mappedChunkType);
        if (Mappings.isIntIdIdentity(protocol.getMappingData().getBlockStateMappings())) {
            return chunk;
        }

        for (final ChunkSection section : chunk.getSections()) {
            final DataPalette blockPalette = section.palette(PaletteType.BLOCKS);
            blockPalette.replaceIds(protocol.getMappingData()::getNewBlockStateId);
        }
        return chunk;
    }

    protected Type<Chunk> createChunkType(ChunkTypeSupplier supplier, EntityTracker tracker, boolean mapped) {
        // Cached in the tracker and invalidated when the section height or biome count changes
        Type<Chunk> type = tracker.chunkType(mapped);
        if (type == null) {
            final Mappings blockStateMappings = protocol.getMappingData().getBlockStateMappings();
            type = supplier.supply(
                tracker.currentWorldSectionHeight(),
                MathUtil.ceilLog2(mapped ? blockStateMappings.mappedSize() : blockStateMappings.size()),
                MathUtil.ceilLog2(tracker.biomesSent())
            );
            tracker.setChunkType(mapped, type);
        }
        return type;
    }

    public void registerBlockEntityData1_18(C packetType) {
        protocol.registerClientbound(packetType, wrapper -> {
            final BlockPosition position = wrapper.passthrough(positionType);

            final int blockEntityId = wrapper.read(Types.VAR_INT);
            final Mappings mappings = protocol.getMappingData().getBlockEntityMappings();
            if (mappings != null) {
                final int mappedBlockEntityId = mappings.getNewId(blockEntityId);
                if (mappedBlockEntityId == -1) {
                    wrapper.cancel();
                    return;
                }
                wrapper.write(Types.VAR_INT, mappedBlockEntityId);
            } else {
                wrapper.write(Types.VAR_INT, blockEntityId);
            }

            final CompoundTag tag = wrapper.passthrough(compoundTagType);
            if (tag != null) {
                final BlockEntity blockEntity = new BlockEntityImpl(BlockEntity.pack(position.x(), position.z()), (short) position.y(), blockEntityId, tag);
                handleBlockEntity(wrapper.user(), blockEntity);
            }
        });
    }

    /**
     * Handles a block entity for rewriting using 1.18+ types. Called with the block entity after its id has been mapped.
     *
     * @param connection  the user connection
     * @param blockEntity the block entity
     */
    public void handleBlockEntity(final UserConnection connection, final BlockEntity blockEntity) {
    }

    @FunctionalInterface
    public interface ChunkTypeSupplier {

        Type<Chunk> supply(int ySectionCount, int globalPaletteBlockBits, int globalPaletteBiomeBits);
    }
}
