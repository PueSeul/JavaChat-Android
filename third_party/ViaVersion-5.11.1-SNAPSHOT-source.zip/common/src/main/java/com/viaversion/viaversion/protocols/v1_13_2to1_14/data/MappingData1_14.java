/*
 * This file is part of ViaVersion - https://github.com/ViaVersion/ViaVersion
 * Copyright (C) 2016-2026 ViaVersion and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.viaversion.viaversion.protocols.v1_13_2to1_14.data;

import com.viaversion.nbt.tag.CompoundTag;
import com.viaversion.viaversion.api.Via;
import com.viaversion.viaversion.api.data.MappingDataBase;
import com.viaversion.viaversion.api.data.MappingDataLoader;
import com.viaversion.viaversion.api.data.IdRanges;
import it.unimi.dsi.fastutil.ints.IntSet;

public class MappingData1_14 extends MappingDataBase {
    private IntSet motionBlocking;
    private IntSet nonFullBlocks;

    public MappingData1_14() {
        super("1.13.2", "1.14");
    }

    @Override
    public void loadExtras(final CompoundTag data) {
        final CompoundTag heightmap = MappingDataLoader.INSTANCE.loadNBT("heightmap-1.14.nbt");
        this.motionBlocking = IdRanges.decode(heightmap.getByteArrayTag("motionBlocking"));

        if (Via.getConfig().isNonFullBlockLightFix()) {
            this.nonFullBlocks = IdRanges.decode(heightmap.getByteArrayTag("nonFullBlocks"));
        }
    }

    public IntSet getMotionBlocking() {
        return motionBlocking;
    }

    public IntSet getNonFullBlocks() {
        return nonFullBlocks;
    }
}
